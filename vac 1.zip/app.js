// Official 1974 India - Sri Lanka IMBL Border Coordinates (Palk Strait)[cite: 1]
const IMBL_POINTS = [
  [10.0833, 80.05],
  [9.95, 79.5833],
  [9.6692, 79.3767],
  [9.3633, 79.5117],
  [9.2167, 79.5333],
  [9.1, 79.5333],
];

// Helper: 16-Point Nautical Cardinal / Intercardinal Direction Converter
function degreesToCardinal(deg) {
  const normalized = ((deg % 360) + 360) % 360;
  const directions = [
    { code: "N", name: "NORTH" },
    { code: "NNE", name: "NORTH-NORTHEAST" },
    { code: "NE", name: "NORTHEAST" },
    { code: "ENE", name: "EAST-NORTHEAST" },
    { code: "E", name: "EAST" },
    { code: "ESE", name: "EAST-SOUTHEAST" },
    { code: "SE", name: "SOUTHEAST" },
    { code: "SSE", name: "SOUTH-SOUTHEAST" },
    { code: "S", name: "SOUTH" },
    { code: "SSW", name: "SOUTH-SOUTHWEST" },
    { code: "SW", name: "SOUTHWEST" },
    { code: "WSW", name: "WEST-SOUTHWEST" },
    { code: "W", name: "WEST" },
    { code: "WNW", name: "WEST-NORTHWEST" },
    { code: "NW", name: "NORTHWEST" },
    { code: "NNW", name: "NORTH-NORTHWEST" },
  ];
  const idx = Math.round(normalized / 22.5) % 16;
  return directions[idx];
}

// Default Fleet State Definitions with Ambient Temperature Parameter[cite: 1]
const DEFAULTS = {
  hw: {
    lat: 9.4500,
    lon: 79.4000,
    heading: 125,
    speed: 5.0,
    pressure: 1013.3,
    wind: 8,
    wave: 0.6,
    roll: 1,
    pitch: 1,
    temp: 31.2,
  },
  b1: {
    lat: 9.6000,
    lon: 79.3000,
    heading: 90,
    speed: 8.0,
    pressure: 1008,
    wind: 14,
    wave: 1.2,
    roll: 4,
    pitch: 2,
    temp: 30.5,
  },
  b2: {
    lat: 9.6600,
    lon: 79.3700,
    heading: 210,
    speed: 12.0,
    pressure: 1012,
    wind: 10,
    wave: 0.8,
    roll: 3,
    pitch: 1,
    temp: 29.8,
  },
};

// Fleet Object
const fleet = {
  hw: {
    id: "hw",
    code: "H01",
    name: "Boat H01 (ESP32)",
    type: "hardware",
    isSos: false,
    ...DEFAULTS.hw,
    risk: 20,
    distImblKm: 1.2,
    track: [],
    lastPacketTime: Date.now(),
  },
  b1: {
    id: "b1",
    code: "B01",
    name: "Boat 1 (Simulated)",
    type: "simulated",
    isSos: false,
    ...DEFAULTS.b1,
    risk: 25,
    distImblKm: 3.2,
    track: [],
  },
  b2: {
    id: "b2",
    code: "B02",
    name: "Boat 2 (Simulated)",
    type: "simulated",
    isSos: false,
    ...DEFAULTS.b2,
    risk: 22,
    distImblKm: 1.4,
    track: [],
  },
};

let selectedId = "hw";
let isAudioMuted = true;
let alertAcknowledged = false;
let audioCtx = null;
let currentTab = "sensors";
let wavePhase = 0;
let lastAudioPlayTime = 0;
let activeCollisionPair = null;
let mqttClient = null;
let showLoRaHalo = true;

// =========================================================================
// CONTINUOUS RISK VS TIME SAMPLING ENGINE (0s -> INFINITY IN 10s INTERVALS)
// =========================================================================
let secondsElapsed = 60;
const riskTimeHistory = {
  labels: ["0s", "10s", "20s", "30s", "40s", "50s", "60s"],
  scores: [18, 19, 20, 20, 22, 21, 20],
};

let riskTimeChart = null;

// Local Storage
function loadSavedConfig() {
  try {
    const saved = localStorage.getItem("sentinel_fleet_config");
    if (saved) {
      const parsed = JSON.parse(saved);
      Object.keys(parsed).forEach((id) => {
        if (fleet[id] && parsed[id].lat && parsed[id].lat > 5) {
          Object.assign(fleet[id], parsed[id]);
        }
      });
    }
  } catch (e) {
    console.warn("Could not load from localStorage", e);
  }
}

function saveConfig() {
  try {
    const toSave = {};
    Object.keys(fleet).forEach((id) => {
      // Hardware Boat parameters are managed strictly by ESP32, skip manual saves
      if (fleet[id].type === "simulated") {
        toSave[id] = {
          lat: fleet[id].lat,
          lon: fleet[id].lon,
          heading: fleet[id].heading,
          speed: fleet[id].speed,
          pressure: fleet[id].pressure,
          wind: fleet[id].wind,
          wave: fleet[id].wave,
          roll: fleet[id].roll,
          pitch: fleet[id].pitch,
          temp: fleet[id].temp,
        };
      }
    });
    localStorage.setItem("sentinel_fleet_config", JSON.stringify(toSave));
  } catch (e) {
    console.warn("Could not save to localStorage", e);
  }
}

// Geodesic Math[cite: 1]
function getDistanceInKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

function getBearingDegrees(lat1, lon1, lat2, lon2) {
  const rad = Math.PI / 180;
  const φ1 = lat1 * rad, φ2 = lat2 * rad;
  const Δλ = (lon2 - lon1) * rad;
  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}

function getDistanceToSegment(p, v, w) {
  const l2 = Math.pow(v[0] - w[0], 2) + Math.pow(v[1] - w[1], 2);
  if (l2 === 0) return getDistanceInKm(p[0], p[1], v[0], v[1]);
  let t = ((p[0] - v[0]) * (w[0] - v[0]) + (p[1] - v[1]) * (w[1] - v[1])) / l2;
  t = Math.max(0, Math.min(1, t));
  return getDistanceInKm(p[0], p[1], v[0] + t * (w[0] - v[0]), v[1] + t * (w[1] - v[1]));
}

function calculateDistanceToIMBL(lat, lon) {
  let minDistance = Infinity;
  for (let i = 0; i < IMBL_POINTS.length - 1; i++) {
    const dist = getDistanceToSegment([lat, lon], IMBL_POINTS[i], IMBL_POINTS[i + 1]);
    if (dist < minDistance) minDistance = dist;
  }
  return minDistance;
}

// Relative Motion CPA Collision Detection[cite: 1]
function calculateCPA(v1, v2) {
  const knotsToKmh = 1.852;
  const vx1 = v1.speed * knotsToKmh * Math.sin((v1.heading * Math.PI) / 180);
  const vy1 = v1.speed * knotsToKmh * Math.cos((v1.heading * Math.PI) / 180);
  const vx2 = v2.speed * knotsToKmh * Math.sin((v2.heading * Math.PI) / 180);
  const vy2 = v2.speed * knotsToKmh * Math.cos((v2.heading * Math.PI) / 180);

  const dvx = vx1 - vx2;
  const dvy = vy1 - vy2;
  const dv2 = dvx * dvx + dvy * dvy;

  const currentDistKm = getDistanceInKm(v1.lat, v1.lon, v2.lat, v2.lon);

  if (dv2 === 0) return { cpa: currentDistKm, tcpa: 0, currentDistKm };

  const dx = (v2.lon - v1.lon) * 111.32 * Math.cos(((v1.lat + v2.lat) / 2) * (Math.PI / 180));
  const dy = (v2.lat - v1.lat) * 111.32;

  const tcpaHours = (dx * dvx + dy * dvy) / dv2;
  if (tcpaHours < 0) return { cpa: currentDistKm, tcpa: 0, currentDistKm };

  const cpaX = dx - dvx * tcpaHours;
  const cpaY = dy - dvy * tcpaHours;
  return {
    cpa: Math.sqrt(cpaX * cpaX + cpaY * cpaY),
    tcpa: tcpaHours * 60,
    currentDistKm,
  };
}

// Risk Calculation Engine (Incorporating Wind, Wave, Pressure, Attitude, Temperature & Collision)[cite: 1]
function computeRisk(vessel, allFleet) {
  const distKm = calculateDistanceToIMBL(vessel.lat, vessel.lon);
  vessel.distImblKm = distKm;

  const absRoll = Math.abs(vessel.roll || 0);
  const absPitch = Math.abs(vessel.pitch || 0);

  // 1. Environmental & Dynamics Components
  const windScore = Math.min(25, ((vessel.wind || 0) / 50) * 25);
  const waveScore = Math.min(25, ((vessel.wave || 0) / 6) * 25);
  const pressScore = Math.max(0, Math.min(15, ((1013 - (vessel.pressure || 1013)) / 60) * 15));
  const proxScore = Math.max(0, 15 * (1 - distKm / 5));

  // Temperature stress component (>35°C escalates vessel distress risk)
  const tempExcess = Math.max(0, (vessel.temp || 30) - 32);
  const tempScore = Math.min(10, (tempExcess / 15) * 10);

  // 2. Capsize / Severe Heel Dynamic Trigger (Roll >= 60° or Pitch >= 50°)
  const isCapsized = absRoll >= 60 || absPitch >= 50;
  let attScore = isCapsized ? 50 : Math.min(20, ((absRoll + absPitch) / 45) * 20);

  let score = windScore + waveScore + pressScore + attScore + proxScore + tempScore;
  vessel.hasCollisionDanger = false;
  vessel.hasCollisionCaution = false;
  vessel.collisionTarget = null;

  if (allFleet) {
    Object.keys(allFleet).forEach((otherId) => {
      const other = allFleet[otherId];
      if (other.code !== vessel.code) {
        const cpaRes = calculateCPA(vessel, other);

        // Critical Impact Warning (< 600m or imminent CPA vector)
        if (cpaRes.currentDistKm < 0.6 || (cpaRes.cpa < 0.35 && cpaRes.tcpa > 0 && cpaRes.tcpa < 6)) {
          score += 45;
          vessel.hasCollisionDanger = true;
          vessel.collisionTarget = other.code;
          vessel.collisionDistM = Math.round(cpaRes.currentDistKm * 1000);
          vessel.collisionTcpa = cpaRes.tcpa.toFixed(1);
        }
        // Early Safety Warning Corridor (< 2.0 km / 2000m)
        else if (cpaRes.currentDistKm < 2.0 || (cpaRes.cpa < 1.0 && cpaRes.tcpa > 0 && cpaRes.tcpa < 12)) {
          score += 20;
          vessel.hasCollisionCaution = true;
          vessel.collisionTarget = other.code;
          vessel.collisionDistM = Math.round(cpaRes.currentDistKm * 1000);
          vessel.collisionTcpa = cpaRes.tcpa.toFixed(1);
        }
      }
    });
  }

  if (vessel.isSos) score = Math.max(score, 90);

  const rounded = Math.min(100, Math.round(score));
  vessel.risk = rounded;

  let level = "LOW";
  let color = "#10b981";

  if (isCapsized || rounded >= 70 || distKm <= 0.5 || vessel.isSos || vessel.hasCollisionDanger) {
    level = "HIGH";
    color = "#ef4444";
  } else if (rounded >= 35 || distKm <= 2.0 || vessel.hasCollisionCaution) {
    level = "MEDIUM";
    color = "#f59e0b";
  }

  return { rounded, level, color, isCapsized, windScore, waveScore, pressScore, proxScore, attScore };
}

// Calculate Safe Escape Heading with Cardinal/Intercardinal Direction Strings & Threat Sync
function computeEscapeVector(vessel, allFleet) {
  let threat = "None Detected";
  let isDanger = false;
  let isCaution = false;
  let recommendedHeading = 240; 

  const distKm = calculateDistanceToIMBL(vessel.lat, vessel.lon);

  // 1. Proximity & Collision Check
  if (allFleet) {
    let closestDist = Infinity;
    let closestTarget = null;
    let isCollisionThreat = false;

    Object.keys(allFleet).forEach((otherId) => {
      const other = allFleet[otherId];
      if (other.code !== vessel.code) {
        const distToOther = getDistanceInKm(vessel.lat, vessel.lon, other.lat, other.lon);
        if (distToOther < 2.0 && distToOther < closestDist) {
          closestDist = distToOther;
          closestTarget = other;
          isCollisionThreat = true;
        }
      }
    });

    if (isCollisionThreat && closestTarget) {
      const bearingToOther = getBearingDegrees(vessel.lat, vessel.lon, closestTarget.lat, closestTarget.lon);
      const distM = Math.round(closestDist * 1000);

      if (closestDist < 0.6) {
        threat = `Collision Imminent: ${closestTarget.code} (${distM}m)`;
        isDanger = true;
      } else {
        threat = `2km Caution: ${closestTarget.code} (${distM}m)`;
        isCaution = true;
      }

      recommendedHeading = Math.round((bearingToOther + 180) % 360);
    }
  }

  // 2. IMBL Border Check
  if (!isDanger) {
    if (distKm <= 0.5) {
      threat = `IMBL Border Breach (${Math.round(distKm * 1000)}m)`;
      isDanger = true;
      recommendedHeading = 250;
    } else if (distKm <= 2.0 && !isCaution) {
      threat = `Approaching IMBL Buffer (${distKm.toFixed(2)}km)`;
      isCaution = true;
      recommendedHeading = 240;
    }
  }

  const curr = vessel.heading || 0;
  const diff = (recommendedHeading - curr + 360) % 360;
  let rudderDirection = "MIDSHIPS";
  let rudderAngle = 0;

  if (diff > 180) {
    rudderAngle = 360 - diff;
    rudderDirection = `PORT ${rudderAngle}°`;
  } else if (diff > 0) {
    rudderAngle = diff;
    rudderDirection = `STARBOARD ${rudderAngle}°`;
  }

  const currentDir = degreesToCardinal(curr);
  const recommendedDir = degreesToCardinal(recommendedHeading);

  return {
    currentHeading: curr,
    currentDir,
    recommendedHeading,
    recommendedDir,
    rudderDirection,
    rudderAngle,
    threat,
    isDanger,
    isCaution
  };
}

// 360 Degree Marine Compass with Cardinal Labels & Escape Vector Display
function drawCompassScope(currentHeading, recommendedHeading, isDanger, isCaution) {
  const canvas = document.getElementById("compassCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  const cx = w / 2;
  const cy = h / 2;
  const r = 38;

  ctx.clearRect(0, 0, w, h);

  // Outer Reticle Ring
  ctx.strokeStyle = "rgba(56, 189, 248, 0.25)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.stroke();

  // Cardinal Direction Ticks (N, S, E, W)
  ctx.font = "bold 8.5px 'Space Mono', monospace";
  ctx.fillStyle = "rgba(130, 154, 177, 0.9)";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("N", cx, cy - r + 7);
  ctx.fillText("S", cx, cy + r - 7);
  ctx.fillText("E", cx + r - 7, cy);
  ctx.fillText("W", cx - r + 7, cy);

  // Intercardinal Labels (NE, NW, SE, SW)
  ctx.font = "6.5px 'Space Mono', monospace";
  ctx.fillStyle = "rgba(130, 154, 177, 0.45)";
  const diagDist = r - 8;
  const diagOffset = Math.sin(Math.PI / 4) * diagDist;
  ctx.fillText("NE", cx + diagOffset, cy - diagOffset);
  ctx.fillText("NW", cx - diagOffset, cy - diagOffset);
  ctx.fillText("SE", cx + diagOffset, cy + diagOffset);
  ctx.fillText("SW", cx - diagOffset, cy + diagOffset);

  // Angle Ticks around circle
  ctx.strokeStyle = "rgba(130, 154, 177, 0.3)";
  ctx.lineWidth = 1;
  for (let a = 0; a < 360; a += 30) {
    const rad = (a * Math.PI) / 180;
    const r1 = r - 2;
    const r2 = r - 4;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(rad) * r1, cy + Math.sin(rad) * r1);
    ctx.lineTo(cx + Math.cos(rad) * r2, cy + Math.sin(rad) * r2);
    ctx.stroke();
  }

  // Recommended Escape Vector (Arrow)
  const recRad = ((recommendedHeading - 90) * Math.PI) / 180;
  ctx.save();
  ctx.strokeStyle = isDanger ? "#ef4444" : isCaution ? "#f59e0b" : "#10b981";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx + Math.cos(recRad) * (r - 7), cy + Math.sin(recRad) * (r - 7));
  ctx.stroke();

  const tipX = cx + Math.cos(recRad) * (r - 4);
  const tipY = cy + Math.sin(recRad) * (r - 4);
  ctx.fillStyle = isDanger ? "#ef4444" : isCaution ? "#f59e0b" : "#10b981";
  ctx.beginPath();
  ctx.arc(tipX, tipY, 4, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  // Current Heading Needle (Red Dashed Line)
  const currRad = ((currentHeading - 90) * Math.PI) / 180;
  ctx.save();
  ctx.strokeStyle = "#ef4444";
  ctx.lineWidth = 2.2;
  ctx.setLineDash([3, 2]);
  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx + Math.cos(currRad) * (r - 9), cy + Math.sin(currRad) * (r - 9));
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.restore();

  // Center Pivot Boss
  ctx.fillStyle = "#070d18";
  ctx.strokeStyle = "#38bdf8";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.arc(cx, cy, 3.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
}

// Map Initialization[cite: 1]
const map = L.map("geomap", { zoomControl: false }).setView([9.55, 79.5], 9);
L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}", {
  attribution: "&copy; Esri World Imagery",
  maxZoom: 17,
}).addTo(map);

// Add IMBL Boundary & Buffer Zones[cite: 1]
L.polyline(IMBL_POINTS, { color: "#ef4444", weight: 2.5, dashArray: "6,6" }).addTo(map);
function offsetPoints(pts, dLat, dLon) {
  return pts.map((p) => [p[0] + dLat, p[1] + dLon]);
}
L.polyline(offsetPoints(IMBL_POINTS, -0.018, -0.018), { color: "#f59e0b", weight: 1.5, dashArray: "4,4", opacity: 0.6 }).addTo(map);
L.polyline(offsetPoints(IMBL_POINTS, -0.0045, -0.0045), { color: "#ef4444", weight: 1.5, dashArray: "2,2", opacity: 0.8 }).addTo(map);

const markers = {};
const vectorLines = {};
const loraCircles = {};

function getVesselSvg(color, code) {
  return `
    <svg class="tactical-boat-svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
      <polygon points="50,2 43,26 57,26" fill="${color}" stroke="#ffffff" stroke-width="1.5"/>
      <path d="M 50,18 C 68,26 74,55 64,88 L 36,88 C 26,55 32,26 50,18 Z" fill="#081426" stroke="${color}" stroke-width="3"/>
      <rect x="42" y="44" width="16" height="24" rx="2" fill="#1b3a57" stroke="#ffffff" stroke-width="1.2"/>
      <circle cx="50" cy="34" r="4.5" fill="${color}"/>
      <rect x="25" y="68" width="50" height="15" rx="3" fill="#040911" stroke="${color}" stroke-width="1.5"/>
      <text x="50" y="79" font-family="'Space Mono', monospace" font-size="11" font-weight="900" fill="#ffffff" text-anchor="middle" letter-spacing="0.5">${code}</text>
    </svg>
  `;
}

// Markers Init with 15km LoRa P2P Halos[cite: 1]
Object.values(fleet).forEach((v) => {
  const isHardware = v.type === "hardware";
  const marker = L.marker([v.lat, v.lon], {
    draggable: !isHardware,
    icon: L.divIcon({
      className: "custom-div-icon",
      html: `<div class="tactical-marker-wrap" id="marker-wrap-${v.id}">${getVesselSvg("#10b981", v.code)}</div>`,
      iconSize: [44, 44],
      iconAnchor: [22, 22],
    }),
  }).addTo(map);

  marker.on("click", () => selectBoat(v.id));

  marker.on("drag", (e) => {
    const pos = e.target.getLatLng();
    v.lat = parseFloat(pos.lat.toFixed(4));
    v.lon = parseFloat(pos.lng.toFixed(4));
    saveConfig();
    selectBoat(v.id);
  });

  markers[v.id] = marker;
  vectorLines[v.id] = L.polyline([], { color: "#10b981", weight: 2.5, dashArray: "4,4" }).addTo(map);

  // 15 km LoRa Coverage Ring (15,000 meters)
  loraCircles[v.id] = L.circle([v.lat, v.lon], {
    radius: 15000,
    color: "#00f0ff",
    weight: 1,
    dashArray: "5, 5",
    fillColor: "#00f0ff",
    fillOpacity: 0.035,
  }).addTo(map);
});

// Collision Intercept Line Layer
const collisionVectorPolyline = L.polyline([], {
  color: "#ff2222",
  weight: 3,
  dashArray: "6,6",
  className: "collision-danger-pulse"
}).addTo(map);

function toggleLoRaCircles() {
  showLoRaHalo = !showLoRaHalo;
  Object.values(loraCircles).forEach((c) => {
    if (showLoRaHalo) c.addTo(map);
    else map.removeLayer(c);
  });
}

// 3D Tactical Inclinometer
function drawAttitude(roll, pitch) {
  const canvas = document.getElementById("attitudeCanvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const w = canvas.width;
  const h = canvas.height;
  const cx = w / 2;
  const cy = h / 2;

  ctx.clearRect(0, 0, w, h);

  const rollTxt = document.getElementById("hudRollTxt");
  const pitchTxt = document.getElementById("hudPitchTxt");
  const warningBadge = document.getElementById("heelWarningBadge");

  if (rollTxt) rollTxt.innerText = `R: ${Math.round(roll)}°`;
  if (pitchTxt) pitchTxt.innerText = `P: ${Math.round(pitch)}°`;

  const isDangerousHeel = Math.abs(roll) >= 30 || Math.abs(pitch) >= 25;
  if (warningBadge) {
    warningBadge.style.display = isDangerousHeel ? "block" : "none";
  }

  /* Horizon */
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate((roll * Math.PI) / 180);
  const pitchShift = Math.max(-28, Math.min(28, pitch * 1.4));
  ctx.translate(0, pitchShift);

  const seaGrad = ctx.createLinearGradient(0, 0, 0, h);
  seaGrad.addColorStop(0, "#083344");
  seaGrad.addColorStop(1, "#031e2b");
  ctx.fillStyle = seaGrad;
  ctx.fillRect(-w, 0, w * 2, h * 2);

  const skyGrad = ctx.createLinearGradient(0, -h, 0, 0);
  skyGrad.addColorStop(0, "#0f172a");
  skyGrad.addColorStop(1, "#1e293b");
  ctx.fillStyle = skyGrad;
  ctx.fillRect(-w, -h * 2, w * 2, h * 2);

  ctx.strokeStyle = isDangerousHeel ? "#ef4444" : "#38bdf8";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(-w, 0);
  ctx.lineTo(w, 0);
  ctx.stroke();
  ctx.restore();

  /* Water Swell */
  ctx.save();
  wavePhase += 0.05;
  ctx.fillStyle = "rgba(14, 116, 144, 0.35)";
  ctx.beginPath();
  ctx.moveTo(0, cy + 18);
  for (let x = 0; x <= w; x += 5) {
    const waveY = cy + 18 + Math.sin(x * 0.06 + wavePhase) * 3;
    ctx.lineTo(x, waveY);
  }
  ctx.lineTo(w, h);
  ctx.lineTo(0, h);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  /* Trimaran Hull */
  ctx.save();
  ctx.translate(cx, cy + 4);
  ctx.rotate((roll * Math.PI) / 180);

  ctx.fillStyle = isDangerousHeel ? "#7f1d1d" : "#0284c7";
  ctx.fillRect(-28, 6, 8, 10);
  ctx.fillRect(20, 6, 8, 10);

  ctx.fillStyle = isDangerousHeel ? "#991b1b" : "#0f3659";
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 1.4;
  ctx.beginPath();
  ctx.moveTo(-20, 0);
  ctx.lineTo(20, 0);
  ctx.lineTo(14, 16);
  ctx.lineTo(0, 20);
  ctx.lineTo(-14, 16);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();

  ctx.strokeStyle = "#94a3b8";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-26, 4);
  ctx.lineTo(26, 4);
  ctx.stroke();

  ctx.fillStyle = "#1e293b";
  ctx.strokeStyle = isDangerousHeel ? "#ef4444" : "#f59e0b";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.rect(-8, -12, 16, 12);
  ctx.fill();
  ctx.stroke();

  ctx.strokeStyle = "#38bdf8";
  ctx.beginPath();
  ctx.moveTo(0, -12);
  ctx.lineTo(0, -18);
  ctx.moveTo(-4, -16);
  ctx.lineTo(4, -16);
  ctx.stroke();
  ctx.restore();

  ctx.strokeStyle = "#facc15";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(cx - 38, cy + 4);
  ctx.lineTo(cx - 24, cy + 4);
  ctx.moveTo(cx + 24, cy + 4);
  ctx.lineTo(cx + 38, cy + 4);
  ctx.arc(cx, cy + 4, 2, 0, Math.PI * 2);
  ctx.stroke();
}

// Select Boat with Hardware Lockout Protection
function selectBoat(id) {
  selectedId = id;
  const v = fleet[id];
  const r = computeRisk(v, fleet);

  document.getElementById("detailBoatTitle").innerText = `${v.name} (Selected)`;
  document.getElementById("detailTypeTag").innerText = v.type === "hardware" ? "HARDWARE (ESP32)" : "SIMULATED";
  document.getElementById("detailRiskVal").innerText = r.rounded;
  document.getElementById("detailRiskVal").style.color = r.color;
  document.getElementById("detailRiskGauge").style.borderColor = r.color;
  document.getElementById("detailRiskLevelText").innerText = r.level;
  document.getElementById("detailRiskLevelText").style.color = r.color;
  document.getElementById("detailRiskLevelText").style.borderColor = r.color;

  const distM = Math.round(v.distImblKm * 1000);
  document.getElementById("detailImblDist").innerText = `${distM} m`;
  document.getElementById("detailSpeed").innerText = `${v.speed.toFixed(1)} kn`;

  const headCard = degreesToCardinal(v.heading);
  document.getElementById("detailHeading").innerText = `${v.heading}° (${headCard.code})`;

  document.getElementById("sRoll").innerText = `${v.roll}°`;
  document.getElementById("sPitch").innerText = `${v.pitch}°`;
  document.getElementById("sPress").innerText = `${v.pressure} hPa`;
  document.getElementById("sWind").innerText = `${v.wind} kn`;
  document.getElementById("sWave").innerText = `${v.wave} m`;
  document.getElementById("sTemp").innerText = `${(v.temp || 30.5).toFixed(1)} °C`;

  // HARDWARE PROTECTION: If Boat H01 (hardware) is selected, lock manual sliders
  const isHw = (v.type === "hardware");
  const lockNotice = document.getElementById("hwLockNotice");
  const scrollArea = document.getElementById("controlsScrollableArea");
  const toggleSosBtn = document.getElementById("btnToggleSos");
  const resetBtn = document.getElementById("btnResetDefaults");

  if (isHw) {
    if (lockNotice) lockNotice.style.display = "flex";
    if (scrollArea) scrollArea.style.opacity = "0.35";
    if (scrollArea) scrollArea.style.pointerEvents = "none";
    if (toggleSosBtn) toggleSosBtn.disabled = true;
    if (resetBtn) resetBtn.disabled = true;
  } else {
    if (lockNotice) lockNotice.style.display = "none";
    if (scrollArea) scrollArea.style.opacity = "1";
    if (scrollArea) scrollArea.style.pointerEvents = "auto";
    if (toggleSosBtn) toggleSosBtn.disabled = false;
    if (resetBtn) resetBtn.disabled = false;
  }

  // Inputs Sync
  document.getElementById("inpLat").value = v.lat.toFixed(4);
  document.getElementById("inpLon").value = v.lon.toFixed(4);
  document.getElementById("ctrlLatVal").innerText = v.lat.toFixed(4);
  document.getElementById("ctrlLonVal").innerText = v.lon.toFixed(4);

  document.getElementById("sliderWind").value = v.wind;
  document.getElementById("valWind").innerText = `${v.wind} kn`;
  document.getElementById("sliderWave").value = v.wave;
  document.getElementById("valWave").innerText = `${v.wave} m`;
  document.getElementById("sliderPress").value = v.pressure;
  document.getElementById("valPress").innerText = `${v.pressure} hPa`;
  document.getElementById("sliderTemp").value = v.temp || 30.5;
  document.getElementById("valTemp").innerText = `${(v.temp || 30.5).toFixed(1)} °C`;
  document.getElementById("sliderHead").value = v.heading;
  document.getElementById("valHead").innerText = `${v.heading}° (${headCard.code})`;
  document.getElementById("sliderSpeed").value = v.speed;
  document.getElementById("valSpeed").innerText = `${v.speed} kn`;
  document.getElementById("sliderRoll").value = v.roll;
  document.getElementById("valRoll").innerText = `${v.roll}°`;
  document.getElementById("sliderPitch").value = v.pitch;
  document.getElementById("valPitch").innerText = `${v.pitch}°`;

  // Donut Breakdown
  document.getElementById("bdCode").innerText = v.code;
  document.getElementById("bdNumber").innerText = r.rounded;
  document.getElementById("breakdownDial").style.borderColor = r.color;
  document.getElementById("bdWind").innerText = `${Math.round(r.windScore)}%`;
  document.getElementById("bdWave").innerText = `${Math.round(r.waveScore)}%`;
  document.getElementById("bdProx").innerText = `${Math.round(r.proxScore)}%`;
  document.getElementById("bdAtt").innerText = `${Math.round(r.attScore)}%`;
  document.getElementById("bdPress").innerText = `${Math.round(r.pressScore)}%`;

  // Dynamic Escape Vector & Recommender Display
  const esc = computeEscapeVector(v, fleet);
  document.getElementById("escCurrHeading").innerText = `${esc.currentHeading}° (${esc.currentDir.code} • ${esc.currentDir.name})`;
  document.getElementById("escRecHeading").innerText = `${esc.recommendedHeading}° (${esc.recommendedDir.code} • ${esc.recommendedDir.name})`;
  document.getElementById("escRudderOrder").innerText = esc.rudderDirection;
  
  const threatElem = document.getElementById("escThreatType");
  threatElem.innerText = esc.threat;
  threatElem.style.color = esc.isDanger ? "#ef4444" : esc.isCaution ? "#f59e0b" : "#10b981";

  const orderTitle = document.getElementById("escapeOrderTitle");
  const rudderBadge = document.getElementById("escapeRudderBadge");

  if (esc.isDanger) {
    orderTitle.className = "escape-order-title danger";
    orderTitle.innerHTML = `&#9888; EVADE: TURN ${esc.rudderDirection} TO ${esc.recommendedHeading}&deg; (${esc.recommendedDir.name})`;
    if (rudderBadge) { rudderBadge.className = "mini-badge danger"; rudderBadge.innerText = "EVASIVE MANEUVER"; }
  } else if (esc.isCaution) {
    orderTitle.className = "escape-order-title warn";
    orderTitle.innerHTML = `&#9888; CAUTION: ADJUST TO ${esc.recommendedHeading}&deg; (${esc.recommendedDir.name})`;
    if (rudderBadge) { rudderBadge.className = "mini-badge warn"; rudderBadge.innerText = "COURSE CORRECTION"; }
  } else {
    orderTitle.className = "escape-order-title";
    orderTitle.innerText = `MAINTAIN CURRENT COURSE \u2022 STEER ${esc.currentHeading}\u00b0 (${esc.currentDir.name})`;
    if (rudderBadge) { rudderBadge.className = "mini-badge safe"; rudderBadge.innerText = "COURSE STABLE"; }
  }

  drawCompassScope(esc.currentHeading, esc.recommendedHeading, esc.isDanger, esc.isCaution);

  // Sync Live Risk vs Time Graph Immediately with Active Vessel Risk
  syncRiskTimeChart(v, r.rounded);

  document.getElementById("detailSosTag").style.display = v.isSos ? "inline-block" : "none";
  document.getElementById("mapCoordsReadout").innerText = `Selected: ${v.code} \u2022 Lat: ${v.lat.toFixed(4)}\u00b0 N | Lon: ${v.lon.toFixed(4)}\u00b0 E`;

  updateAllUI();
}

// Sync Live Risk vs Time Continuous Prediction Curve
function syncRiskTimeChart(vessel, currentRiskScore) {
  if (!riskTimeChart) return;

  // Insert latest score
  riskTimeHistory.scores[riskTimeHistory.scores.length - 1] = currentRiskScore;

  // Trajectory Assessment
  const prevScore = riskTimeHistory.scores[riskTimeHistory.scores.length - 2] || currentRiskScore;
  const delta = currentRiskScore - prevScore;
  const trajectoryElem = document.getElementById("riskTrajectoryText");
  const badgeElem = document.getElementById("riskTrendBadge");

  document.getElementById("liveRiskMetric").innerText = `${currentRiskScore} / 100`;

  if (currentRiskScore >= 70 || delta >= 25) {
    trajectoryElem.innerText = `Drastic Surge (+${delta} pts)`;
    trajectoryElem.style.color = "#ef4444";
    badgeElem.className = "mini-badge danger";
    badgeElem.innerText = "Drastic Increase";
    riskTimeChart.data.datasets[0].borderColor = "#ef4444";
    riskTimeChart.data.datasets[0].backgroundColor = "rgba(239, 68, 68, 0.25)";
  } else if (currentRiskScore >= 35 || delta >= 10) {
    trajectoryElem.innerText = `Gradual Increase (+${delta} pts)`;
    trajectoryElem.style.color = "#f59e0b";
    badgeElem.className = "mini-badge warn";
    badgeElem.innerText = "Gradual Increase";
    riskTimeChart.data.datasets[0].borderColor = "#f59e0b";
    riskTimeChart.data.datasets[0].backgroundColor = "rgba(245, 158, 11, 0.2)";
  } else {
    trajectoryElem.innerText = "Nominal Trajectory";
    trajectoryElem.style.color = "#10b981";
    badgeElem.className = "mini-badge safe";
    badgeElem.innerText = "Risk Stable";
    riskTimeChart.data.datasets[0].borderColor = "#10b981";
    riskTimeChart.data.datasets[0].backgroundColor = "rgba(16, 185, 129, 0.15)";
  }

  riskTimeChart.update();
}

function updateSlider(param, value) {
  // Prevent manual modifications to physical ESP32 Hardware Boat
  if (fleet[selectedId].type === "hardware") return;

  const v = fleet[selectedId];
  v[param] = parseFloat(value);
  saveConfig();
  selectBoat(selectedId);
}

function stepCoord(param, delta) {
  if (fleet[selectedId].type === "hardware") return;

  const v = fleet[selectedId];
  v[param] = parseFloat((v[param] + delta).toFixed(4));
  saveConfig();
  selectBoat(selectedId);
}

function manualCoordChange() {
  if (fleet[selectedId].type === "hardware") return;

  const v = fleet[selectedId];
  v.lat = parseFloat(document.getElementById("inpLat").value) || v.lat;
  v.lon = parseFloat(document.getElementById("inpLon").value) || v.lon;
  saveConfig();
  selectBoat(selectedId);
}

function switchControlTab(tab) {
  currentTab = tab;
  document.getElementById("tabSensorsBtn").classList.toggle("active", tab === "sensors");
  document.getElementById("tabControlsBtn").classList.toggle("active", tab === "controls");
  document.getElementById("tabSensorsContent").style.display = tab === "sensors" ? "block" : "none";
  document.getElementById("tabControlsContent").style.display = tab === "controls" ? "block" : "none";
}

// Send Real-Time Command Back to Hardware ESP32 LCD
function notifyEsp32Hardware(alertType, distMeters, otherBoatCode) {
  if (mqttClient && mqttClient.connected) {
    const payload = JSON.stringify({
      alert: alertType,
      dist: distMeters,
      target: otherBoatCode
    });
    mqttClient.publish("sentinel-line/triode_titans/hwcmd", payload);
  }
}

// Master UI & Collision Check with 15km LoRa
function updateAllUI() {
  let highestRisk = 0;
  let highestVessel = fleet.hw;
  let nearestImblDist = Infinity;
  let criticalCollision = false;
  let cautionCollision = false;
  let collisionPairText = "";
  let hwCollisionData = null;

  const container = document.getElementById("vesselList");
  container.innerHTML = "";

  activeCollisionPair = null;
  const boatKeys = Object.keys(fleet);

  // Scan all vessel pairs for distance & CPA[cite: 1]
  for (let i = 0; i < boatKeys.length; i++) {
    for (let j = i + 1; j < boatKeys.length; j++) {
      const bA = fleet[boatKeys[i]];
      const bB = fleet[boatKeys[j]];
      const dist = getDistanceInKm(bA.lat, bA.lon, bB.lat, bB.lon);
      const cpa = calculateCPA(bA, bB);

      const involvesHw = (bA.id === "hw" || bB.id === "hw");
      const otherBoat = bA.id === "hw" ? bB : bA;

      // Critical Impact (< 600m or CPA < 350m within 6 mins)
      if (dist < 0.6 || (cpa.cpa < 0.35 && cpa.tcpa > 0 && cpa.tcpa < 6)) {
        criticalCollision = true;
        activeCollisionPair = [bA, bB];
        collisionPairText = `${bA.code} & ${bB.code} (Distance: ${Math.round(dist * 1000)}m)`;
        if (involvesHw) hwCollisionData = { type: "COLLISION_CRITICAL", dist: Math.round(dist * 1000), target: otherBoat.code };
        break;
      }
      // Early Safety Warning (< 2.0 km / 2000m)
      else if (dist < 2.0 || (cpa.cpa < 1.0 && cpa.tcpa > 0 && cpa.tcpa < 12)) {
        cautionCollision = true;
        activeCollisionPair = [bA, bB];
        collisionPairText = `${bA.code} & ${bB.code} (Within 2km Corridor: ${Math.round(dist * 1000)}m)`;
        if (involvesHw && !hwCollisionData) hwCollisionData = { type: "COLLISION_CAUTION", dist: Math.round(dist * 1000), target: otherBoat.code };
      }
    }
    if (criticalCollision) break;
  }

  // Notify physical ESP32 LCD
  if (hwCollisionData) {
    notifyEsp32Hardware(hwCollisionData.type, hwCollisionData.dist, hwCollisionData.target);
  } else {
    notifyEsp32Hardware("NONE", 0, "");
  }

  // Draw Hazard Line on Map
  if (activeCollisionPair) {
    collisionVectorPolyline.setLatLngs([
      [activeCollisionPair[0].lat, activeCollisionPair[0].lon],
      [activeCollisionPair[1].lat, activeCollisionPair[1].lon],
    ]);
    collisionVectorPolyline.setStyle({ color: criticalCollision ? "#ff2222" : "#f59e0b" });
  } else {
    collisionVectorPolyline.setLatLngs([]);
  }

  Object.values(fleet).forEach((v) => {
    const r = computeRisk(v, fleet);
    if (r.rounded > highestRisk) {
      highestRisk = r.rounded;
      highestVessel = v;
    }
    if (v.distImblKm < nearestImblDist) {
      nearestImblDist = v.distImblKm;
    }

    // Leaflet Marker & Rotation[cite: 1]
    if (markers[v.id]) {
      markers[v.id].setLatLng([v.lat, v.lon]);
      const wrap = document.getElementById(`marker-wrap-${v.id}`);
      if (wrap) {
        wrap.innerHTML = getVesselSvg(r.color, v.code);
        wrap.style.transform = `rotate(${v.heading || 0}deg)`;
      }
    }

    // 15 km LoRa Coverage Ring Sync
    if (loraCircles[v.id]) {
      loraCircles[v.id].setLatLng([v.lat, v.lon]);
    }

    // 5-Min Future Vector[cite: 1]
    const distProjKm = (v.speed || 0) * 1.852 * (5 / 60);
    const rad = ((v.heading || 0) * Math.PI) / 180;
    const destLat = v.lat + (distProjKm / 111) * Math.cos(rad);
    const destLon = v.lon + (distProjKm / (111 * Math.cos((v.lat * Math.PI) / 180))) * Math.sin(rad);
    vectorLines[v.id].setLatLngs([[v.lat, v.lon], [destLat, destLon]]);
    vectorLines[v.id].setStyle({ color: r.color });

    // Fleet List Item with Heading Direction
    const isActive = v.id === selectedId;
    const badgeClass = r.level === "HIGH" ? "danger" : r.level === "MEDIUM" ? "warn" : "safe";
    const distM = Math.round(v.distImblKm * 1000);
    const vCard = degreesToCardinal(v.heading);

    const card = document.createElement("div");
    card.className = `vessel-card-mini ${isActive ? "active" : ""}`;
    card.onclick = () => selectBoat(v.id);
    card.innerHTML = `
      <div class="vcard-row1">
        <span class="vcard-id">${v.code}</span>
        <div class="vcard-tags">
          ${v.hasCollisionDanger ? '<span class="mini-badge danger">CRITICAL PROXIMITY</span>' : v.hasCollisionCaution ? '<span class="mini-badge warn">&lt; 2KM PROXIMITY</span>' : ""}
          ${v.isSos ? '<span class="mini-badge danger">SOS ACTIVE</span>' : ""}
          <span class="mini-badge ${badgeClass}">Risk ${r.rounded}/100</span>
          <span class="mini-badge ${badgeClass}">${r.level}</span>
        </div>
      </div>
      <div class="vcard-coords">Lat: ${v.lat.toFixed(4)}° N &bull; Lon: ${v.lon.toFixed(4)}° E</div>
      <div class="vcard-coords">Spd: ${v.speed} kn &bull; Hdg: ${v.heading}° (${vCard.code}) &bull; ${distM} m to IMBL</div>
    `;
    container.appendChild(card);
  });

  // Top Metric Cards
  document.getElementById("kpiTotalBoats").innerText = Object.keys(fleet).length;
  document.getElementById("kpiHighRisk").innerText = Object.values(fleet).filter((v) => computeRisk(v, fleet).level === "HIGH").length;
  document.getElementById("kpiSosActive").innerText = criticalCollision ? "CRITICAL" : cautionCollision ? "CAUTION" : Object.values(fleet).filter((v) => v.isSos).length;
  document.getElementById("kpiNearestImbl").innerText = `${Math.round(nearestImblDist * 1000)} m`;

  // Top Critical Alert Banner
  const sosBanner = document.getElementById("sosBanner");
  const ackBtn = document.getElementById("bannerAckBtn");

  if (criticalCollision) {
    if (!alertAcknowledged) {
      sosBanner.classList.add("critical-flash");
      ackBtn.style.display = "inline-block";
    }
    document.getElementById("bannerIcon").innerHTML = "&#128680;";
    document.getElementById("bannerStatusTitle").innerText = "VESSEL COLLISION HAZARD DETECTED";
    document.getElementById("bannerVesselTag").innerText = collisionPairText;
    document.getElementById("bannerSub").innerText = "Critical Warning: Vessels are dangerously close or on an intersecting collision course.";
    triggerControlledAudioAlert("danger");
  } else if (cautionCollision) {
    sosBanner.classList.remove("critical-flash");
    ackBtn.style.display = "none";
    document.getElementById("bannerIcon").innerHTML = "&#9888;";
    document.getElementById("bannerStatusTitle").innerText = "2 KM COLLISION CAUTION ZONE";
    document.getElementById("bannerVesselTag").innerText = collisionPairText;
    document.getElementById("bannerSub").innerText = "Notice: Vessels approaching within 2000m corridor. Maintain radar watch.";
  } else if (highestRisk >= 70 || highestVessel.isSos) {
    if (!alertAcknowledged) {
      sosBanner.classList.add("critical-flash");
      ackBtn.style.display = "inline-block";
    }
    document.getElementById("bannerIcon").innerHTML = "&#9888;";
    document.getElementById("bannerStatusTitle").innerText = highestVessel.isSos ? "SOS EMERGENCY ACTIVE (HARDWARE BUTTON)" : "HIGH MARITIME RISK DETECTED";
    document.getElementById("bannerVesselTag").innerText = highestVessel.code;
    document.getElementById("bannerSub").innerText = `Critical breach approach. Nearest distance: ${Math.round(highestVessel.distImblKm * 1000)} m`;
    triggerControlledAudioAlert("danger");
  } else {
    sosBanner.classList.remove("critical-flash");
    ackBtn.style.display = "none";
    alertAcknowledged = false;
    document.getElementById("bannerIcon").innerHTML = "&#9875;";
    document.getElementById("bannerStatusTitle").innerText = "FLEET STATUS NOMINAL";
    document.getElementById("bannerVesselTag").innerText = "ALL NODES SAFE";
    document.getElementById("bannerSub").innerText = "All vessels navigating safely within authorized maritime zones.";
  }

  populateAlertFeed();
}

function acknowledgeAlert() {
  alertAcknowledged = true;
  document.getElementById("sosBanner").classList.remove("critical-flash");
  document.getElementById("bannerAckBtn").style.display = "none";
}

function populateAlertFeed() {
  const list = document.getElementById("alertFeedList");
  const alerts = [];
  const time = new Date().toTimeString().split(" ")[0].slice(0, 5);

  if (activeCollisionPair) {
    const dM = Math.round(getDistanceInKm(activeCollisionPair[0].lat, activeCollisionPair[0].lon, activeCollisionPair[1].lat, activeCollisionPair[1].lon) * 1000);
    alerts.push({
      type: dM < 600 ? "danger" : "warn",
      title: dM < 600 ? `CRITICAL COLLISION: ${activeCollisionPair[0].code} & ${activeCollisionPair[1].code}` : `2KM COLLISION CAUTION: ${activeCollisionPair[0].code} & ${activeCollisionPair[1].code}`,
      desc: `Proximity: ${dM}m apart. Relative collision course detected.`,
      time
    });
  }

  Object.values(fleet).forEach((v) => {
    const r = computeRisk(v, fleet);
    if (v.isSos) alerts.push({ type: "danger", title: `SOS Distress - ${v.name}`, desc: "Physical SOS button pressed on ESP32", time });
    if (v.distImblKm <= 0.5) alerts.push({ type: "danger", title: `IMBL Breach - ${v.code}`, desc: `Inside 500m breach corridor (${Math.round(v.distImblKm * 1000)}m)`, time });
    else if (v.distImblKm <= 2.0) alerts.push({ type: "warn", title: `Caution Zone - ${v.code}`, desc: `Approaching IMBL line (${v.distImblKm.toFixed(2)} km)`, time });
    if (Math.abs(v.roll) > 30) alerts.push({ type: "warn", title: `High Tilt - ${v.code}`, desc: `Roll is ${v.roll}° (Limit 30°)`, time });
    if (v.pressure < 998) alerts.push({ type: "warn", title: `Storm Depressure - ${v.code}`, desc: `Barometer dropped to ${v.pressure} hPa`, time });
  });

  document.getElementById("alertCountBadge").innerText = `${alerts.length} Active`;
  list.innerHTML = alerts.map((a) => `
    <div class="alert-item ${a.type}">
      <span>&#9888;</span>
      <div>
        <b>${a.title}</b>
        <div style="color: var(--text-muted)">${a.desc}</div>
      </div>
      <span class="alert-item-time">${a.time}</span>
    </div>
  `).join("");
}

function toggleSelectedSos() {
  if (fleet[selectedId].type === "hardware") return;
  fleet[selectedId].isSos = !fleet[selectedId].isSos;
  selectBoat(selectedId);
}

function resetBoatData() {
  if (fleet[selectedId].type === "hardware") return;
  if (DEFAULTS[selectedId]) {
    Object.assign(fleet[selectedId], DEFAULTS[selectedId]);
    saveConfig();
    selectBoat(selectedId);
  }
}

// 2 KM Proximity Simulation
function testCollisionScenario() {
  fleet.b1.lat = 9.6500;
  fleet.b1.lon = 79.3650;
  fleet.b1.heading = 45;
  fleet.b1.speed = 10;

  fleet.b2.lat = 9.6580;
  fleet.b2.lon = 79.3730;
  fleet.b2.heading = 225;
  fleet.b2.speed = 10;

  saveConfig();
  selectBoat("b1");
}

// =========================================================================
// CONTINUOUS DYNAMIC RISK VS TIME CHART INITIALIZATION
// =========================================================================
function initCharts() {
  const ctxRisk = document.getElementById("riskTimeChart").getContext("2d");
  
  riskTimeChart = new Chart(ctxRisk, {
    type: "line",
    data: {
      labels: riskTimeHistory.labels,
      datasets: [
        {
          label: "Predicted Risk Index (0-100)",
          data: riskTimeHistory.scores,
          borderColor: "#10b981",
          backgroundColor: "rgba(16, 185, 129, 0.15)",
          fill: true,
          tension: 0.35,
          pointRadius: 3,
          pointHoverRadius: 6,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: {
          backgroundColor: "rgba(7, 13, 24, 0.95)",
          titleFont: { family: "'Space Mono', monospace", size: 8.5 },
          bodyFont: { family: "'Space Mono', monospace", size: 8.5 },
          callbacks: {
            label: function(context) {
              return ` Risk Score: ${context.parsed.y}/100`;
            }
          }
        },
      },
      scales: {
        x: {
          grid: { color: "rgba(255,255,255,0.04)" },
          ticks: { color: "#829ab1", font: { size: 7.5 } },
        },
        y: {
          min: 0,
          max: 100,
          grid: { color: "rgba(255,255,255,0.04)" },
          ticks: {
            color: "#829ab1",
            font: { size: 7.5 },
            stepSize: 25,
          },
        },
      },
    },
  });
}

// Continuous 10-Second Risk vs Time Logging Loop (0s -> Infinity)
setInterval(() => {
  const activeVessel = fleet[selectedId];
  if (!activeVessel || !riskTimeChart) return;

  const currentRisk = activeVessel.risk || 20;

  secondsElapsed += 10;
  riskTimeHistory.labels.shift();
  riskTimeHistory.labels.push(`${secondsElapsed}s`);

  riskTimeHistory.scores.shift();
  riskTimeHistory.scores.push(currentRisk);

  syncRiskTimeChart(activeVessel, currentRisk);
}, 10000);

function zoomToFit() {
  const group = L.featureGroup(Object.values(markers));
  map.fitBounds(group.getBounds().pad(0.3));
}

function zoomToSelected() {
  if (markers[selectedId]) {
    map.setView(markers[selectedId].getLatLng(), 11);
  }
}

// Audio Control
function toggleAudioMute() {
  isAudioMuted = !isAudioMuted;
  document.getElementById("soundText").innerText = isAudioMuted ? "SOUND MUTED" : "ALERT SOUND ON";
  document.getElementById("soundIcon").innerHTML = isAudioMuted ? "&#128263;" : "&#128266;";

  if (isAudioMuted && audioCtx) {
    audioCtx.close();
    audioCtx = null;
  }
}

function triggerControlledAudioAlert(type) {
  if (isAudioMuted || alertAcknowledged) return;

  const now = Date.now();
  if (now - lastAudioPlayTime < 6000) return;
  lastAudioPlayTime = now;

  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.type = "sine";
    osc.frequency.setValueAtTime(type === "danger" ? 800 : 440, audioCtx.currentTime);
    gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);

    osc.start();
    osc.stop(audioCtx.currentTime + 0.3);
  } catch (e) {
    console.warn("Audio policy note:", e);
  }
}

// HiveMQ MQTT Integration & Two-Way ESP32 Hardware Link[cite: 1]
const HARDWARE_CONFIG = {
  broker: "wss://broker.hivemq.com:8884/mqtt",
  telemetryTopic: "sentinel-line/triode_titans/hwboat",
  commandTopic: "sentinel-line/triode_titans/hwcmd"
};

function connectHardwareMQTT() {
  if (typeof mqtt === "undefined") return;
  try {
    mqttClient = mqtt.connect(HARDWARE_CONFIG.broker);
    mqttClient.on("connect", () => {
      mqttClient.subscribe(HARDWARE_CONFIG.telemetryTopic);
      document.getElementById("hwEspStatus").innerText = "Live HiveMQ & LoRa";
    });

    mqttClient.on("message", (topic, message) => {
      try {
        const d = JSON.parse(message.toString());
        const hw = fleet.hw;
        if (typeof d.lat === "number" && d.lat > 5) hw.lat = d.lat;
        if (typeof d.lon === "number" && d.lon > 5) hw.lon = d.lon;
        if (typeof d.pressure === "number") hw.pressure = d.pressure;
        if (typeof d.wind === "number") hw.wind = d.wind;
        if (typeof d.roll === "number") hw.roll = d.roll;
        if (typeof d.pitch === "number") hw.pitch = d.pitch;
        if (typeof d.heading === "number") hw.heading = d.heading;
        if (typeof d.speed === "number") hw.speed = d.speed;
        if (typeof d.temp === "number") hw.temp = d.temp;

        if (typeof d.sos === "boolean") {
          hw.isSos = d.sos;
        }

        hw.lastPacketTime = Date.now();
        selectBoat(selectedId);
      } catch (err) {
        console.warn("MQTT Parse error:", err);
      }
    });
  } catch (e) {
    console.warn("MQTT connection error", e);
  }
}

// Clock updates
setInterval(() => {
  const now = new Date();
  document.getElementById("clockDisplay").innerText = now.toLocaleString("en-US", { timeZone: "Asia/Kolkata" }) + " (IST)";
  const elapsed = Math.round((Date.now() - fleet.hw.lastPacketTime) / 1000);
  document.getElementById("hwUpdated").innerText = `• ${elapsed}s ago`;
}, 1000);

// Gyro & Compass Animation Loop
function animateGyroLoop() {
  const activeBoat = fleet[selectedId];
  if (activeBoat) {
    drawAttitude(activeBoat.roll, activeBoat.pitch);
    const esc = computeEscapeVector(activeBoat, fleet);
    drawCompassScope(esc.currentHeading, esc.recommendedHeading, esc.isDanger, esc.isCaution);
  }
  requestAnimationFrame(animateGyroLoop);
}

// Boot System
loadSavedConfig();
initCharts();
selectBoat("hw");
connectHardwareMQTT();
animateGyroLoop();